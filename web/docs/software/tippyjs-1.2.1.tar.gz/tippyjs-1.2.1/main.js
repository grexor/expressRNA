import './src/scss/tippy.scss'
import tippy from './src/js/tippy.js'

export default tippy
